<?php
define( "DB_DSN", "mysql:host=db_host;dbname=db_name" );
define( "DB_USERNAME", 'db_user' );
define( "DB_PASSWORD", 'db_password' );
?>