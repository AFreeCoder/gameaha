<?php

// Removed since v2.0.0
// Initially this script do cron-job only for Auto Publish plugin, now the script file stored in the plugin folder (Auto Publish)

?>