<?php

require_once( ABSPATH . 'includes/page-category.php' );

?>