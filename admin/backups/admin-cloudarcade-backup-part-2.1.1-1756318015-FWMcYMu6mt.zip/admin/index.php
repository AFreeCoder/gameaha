<?php

die('FORBIDDEN 1010')

?>