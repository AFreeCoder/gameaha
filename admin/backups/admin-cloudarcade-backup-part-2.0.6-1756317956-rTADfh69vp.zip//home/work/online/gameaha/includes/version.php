<?php

define( "VERSION", "2.0.6" );

?>