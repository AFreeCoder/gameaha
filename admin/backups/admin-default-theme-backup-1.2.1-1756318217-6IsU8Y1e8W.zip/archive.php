<?php 
// Deprecated since v1.1.9 , replaced with category.php
?>